import { prisma } from '../db/prisma';
import { AuditLog } from '@prisma/client';

function sanitizeAuditDetails(value: unknown, depth = 0): unknown {
  if (depth > 4) return '[DEPTH_LIMIT]';

  if (typeof value === 'string') {
    return value.length > 500 ? `${value.slice(0, 500)}…` : value;
  }

  if (value === null || typeof value === 'number' || typeof value === 'boolean') {
    return value;
  }

  if (Array.isArray(value)) {
    return value.slice(0, 20).map((item) =>
      sanitizeAuditDetails(item, depth + 1)
    );
  }

  if (typeof value === 'object') {
    const sensitiveKey =
      /(password|passwd|token|secret|cookie|authorization|hash|before|after|session|useragent|email|phone|telepon|nip|nuptk)/i;

    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .filter(([key]) => !sensitiveKey.test(key))
        .slice(0, 50)
        .map(([key, item]) => [
          key,
          sanitizeAuditDetails(item, depth + 1),
        ])
    );
  }

  return undefined;
}

export class AuditLogRepository {
  async logAction(params: {
    userId?: string;
    institutionId?: string;
    action: string;
    resource: string;
    details?: any;
    ipAddress?: string;
  }): Promise<AuditLog | null> {
    if (!process.env.DATABASE_URL) {
      return null;
    }
    try {
      return await prisma.auditLog.create({
        data: {
          action: params.action,
          resource: params.resource,
          details: params.details || {},
          ipAddress: params.ipAddress,
          ...(params.userId ? { user: { connect: { id: params.userId } } } : {}),
          ...(params.institutionId
            ? { institution: { connect: { id: params.institutionId } } }
            : {}),
        },
      });
    } catch (e) {
      console.error('Failed creating audit log record:', e);
      return null;
    }
  }

  async listByInstitution(institutionId: string, limit = 50): Promise<AuditLog[]> {
    return prisma.auditLog.findMany({
      where: { institutionId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }

  async listByUser(userId: string, limit = 50): Promise<AuditLog[]> {
    return prisma.auditLog.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }

  async listLogs(params: { limit?: number; offset?: number; action?: string } = {}): Promise<{
    logs: Array<Pick<AuditLog, 'id' | 'createdAt' | 'action' | 'resource' | 'details' | 'ipAddress'>>;
    total: number;
  }> {
    const limit = Math.min(Math.max(params.limit || 50, 1), 100);
    const offset = Math.max(params.offset || 0, 0);
    const where = params.action ? { action: params.action } : {};

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        select: {
          id: true,
          createdAt: true,
          action: true,
          resource: true,
          details: true,
          ipAddress: true,
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.auditLog.count({ where }),
    ]);

    const sanitizedLogs = logs.map((log) => ({
      ...log,
      details: sanitizeAuditDetails(log.details) as AuditLog['details'],
    }));

    return { logs: sanitizedLogs, total };
  }
}

export const auditLogRepository = new AuditLogRepository();

